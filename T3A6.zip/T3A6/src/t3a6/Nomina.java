package t3a6;

public class Nomina {
private int cantidadDeEmpleados;
private int numeroContrato;
private String tipoDeEmpleado;
private int a�osDeAntig�edad;
private String horastrabajadas;
private float salarioBase;
private String nombre;
private String apellidoPaterno;
private String RFC;
private String CURP;
private String email;
private String telefono;

    public Nomina() {
    }

    public Nomina(int cantidadDeEmpleados, int numeroContrato, String tipoDeEmpleado, int a�osDeAntig�edad, String horastrabajadas, float salarioBase, String nombre, String apellidoPaterno, String RFC, String CURP, String email, String telefono) {
        this.cantidadDeEmpleados = cantidadDeEmpleados;
        this.numeroContrato = numeroContrato;
        this.tipoDeEmpleado = tipoDeEmpleado;
        this.a�osDeAntig�edad = a�osDeAntig�edad;
        this.horastrabajadas = horastrabajadas;
        this.salarioBase = salarioBase;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.RFC = RFC;
        this.CURP = CURP;
        this.email = email;
        this.telefono = telefono;
    }

    public void datos(){
        System.out.println("INFORMACI�N"
            + "NOMBRE: " + getNombre()   
            + "APELLIDO PATERNO: " + getApellidoPaterno()
            + "RFC: " + getRFC()
            + "CURP: " + getCURP()
            + "EMAIL: " + getEmail()
            + "TELEFONO: " + getTelefono());
    
    }

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
            
            
            
    
    public int getCantidadDeEmpleados() {
        return cantidadDeEmpleados;
    }

    public void setCantidadDeEmpleados(int cantidadDeEmpleados) {
        this.cantidadDeEmpleados = cantidadDeEmpleados;
    }

    public int getNumeroContrato() {
        return numeroContrato;
    }

    public void setNumeroContrato(int numeroContrato) {
        this.numeroContrato = numeroContrato;
    }

    public String getTipoDeEmpleado() {
        return tipoDeEmpleado;
    }

    public void setTipoDeEmpleado(String tipoDeEmpleado) {
        this.tipoDeEmpleado = tipoDeEmpleado;
    }

    public int getA�osDeAntig�edad() {
        return a�osDeAntig�edad;
    }

    public void setA�osDeAntig�edad(int a�osDeAntig�edad) {
        this.a�osDeAntig�edad = a�osDeAntig�edad;
    }

    public String getHorastrabajadas() {
        return horastrabajadas;
    }

    public void setHorastrabajadas(String horastrabajadas) {
        this.horastrabajadas = horastrabajadas;
    }

    public float getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(float salarioBase) {
        this.salarioBase = salarioBase;
    }

    public String getNombre() {
        System.out.println("ELVIZ CLAUDETTE");
        return nombre;
    }

    public void setNombre(String nombre) {
        System.out.println("ELVIZ C");
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        System.out.println("GARRIDO");
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getRFC() {
        System.out.println("------");
        return RFC;
    }

    public void setRFC(String RFC) {
        this.RFC = RFC;
    }

    public String getCURP() {
        System.out.println("GAOE030507MOCRSLA3");
        return CURP;
    }

    public void setCURP(String CURP) {
        this.CURP = CURP;
    }

    public String getEmail() {
        System.out.println("Mugiwara.Monkey.D.Luffy07@gmail.com");
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        System.out.println("226-101-3430");
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }


    
}
