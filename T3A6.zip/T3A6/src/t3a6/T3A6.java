package t3a6;

import java.util.Scanner;

public class T3A6 {
    
    public static void main(String[] args) {
     t3a6();
    }
    
    public static void t3a6(){
        
        Nomina Nomina = new Nomina (); 
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("INGRESAR NUMERO DE CONTRATO: ");
        int numeroContrato = scanner.nextInt();
        
        Nomina.datos();
    
    }
}
